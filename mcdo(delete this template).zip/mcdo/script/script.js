 var slider = tns({
    container: '.banner',
    items: 1,
    controls: false,
    autoplayButtonOutput: false,
    slideBy: 'page',
    autoplay: true
  });

