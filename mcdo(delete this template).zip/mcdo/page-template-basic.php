<?php
/* 
Template Name: basic termplate
*/
?>

<?php get_header() ?>
<section class="banner" style="background-image: url(<?php echo get_field('banner') ?>)">  <!--banner--food-->
</section>

<?php the_content() ?>

<?php get_footer() ?>