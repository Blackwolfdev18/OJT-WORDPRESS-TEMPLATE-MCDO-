<?php
function mcdo_custom_quality_post(){
    $qualityPost_label = array(
        'name'          => __('Quality Post','textdomain'),
        'singular_name' => __('Quality Post','textdomain'),
        'add_new'       => __('Add Quality Post', 'textdomain'),
        'add_new_item'  => __('Add new Quality Post', 'textdomain'),
        'edit_item'     => __('Edit Quality Post', 'textdomain'),
        'all_items'     => __('Quality Post', 'textdomain'),
    );

    $qualityPost_args = array(
        'labels'            => $qualityPost_label,
        'public'            => true,
        'capability_type'   => 'post',
        'show_ui'           => true,
        'taxonomies'        => array('post_tag','category'),
        'supports'          => array('title', 'editor', 'thumbnail', 'excerpt'),
    );

    register_post_type('qualityPost', $qualityPost_args);
}
add_action('init', 'mcdo_custom_quality_post');