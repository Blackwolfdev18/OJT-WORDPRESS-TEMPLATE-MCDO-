<?php get_header();?>
<section class="banner" style="background-image: url(<?php echo get_field('banner') ?>)">  <!--banner--food-->
</section>

<section class="activity py">
        <div class="container">
            <?php 
                $activity = new WP_Query(array(
                    'post_type' => 'post'
                ))
            ?>
            <?php if($activity->have_posts()) : while($activity->have_posts()) : $activity->the_post(); ?>
            <!-- Card 1 -->
            <div class="activity__card">
                <?php if(has_post_thumbnail()){
                    the_post_thumbnail();
                    }?>
                <div class="activity__card__content">
                <div>
                    <h2><?php the_title();?></h2>
                    
                </div>
                    <a href="#" class="btn btn-primary w-full">Learn</a>
                </div>
            </div>
            <?php endwhile;
                else:
                    echo "Nomore activity";
                endif;
            ?>
        </div>
        
    </section>
<?php get_footer();?>