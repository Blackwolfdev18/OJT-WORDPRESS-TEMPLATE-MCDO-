<?php get_header();?>
<section class="banner" style="background-image: url(<?php echo get_field('banner') ?>)">  <!--banner--food-->
</section>


<section class="category bg-primary">
        <div class="container">
            <div class="category__wrapper">
            <?php
    if(have_rows("category_menu")) : ?>
    <?php while(have_rows('category_menu') ): the_row(); ?>
                <div class="category__card">
                    <a href="<?php echo get_sub_field('cat_link') ?>">
                    <img src="<?php echo get_sub_field('catimg') ?>" alt="">
                    <h5><?php echo get_sub_field('catlabel') ?></h5>
                    </a>
                </div>
                <?php endwhile; 
            else: 
                echo "No more slider";
        endif;
        ?>
            </div>
        </div>
    </section>


    <section class="quality">
        <div class="container">
            <div class="quality__header">
                <h3 class="mb-1">Food Quality</h3>
                <h5 class="mb-1 text-accent">quality and safety</h5>
                <p>this is mc donald's promise when it comes to food</p>
            </div>
        </div>

            <div class="quality__wrapper">
                <div class="container">
                <?php
    if(have_rows("food_quality")) : ?>
    <?php while(have_rows('food_quality') ): the_row(); ?>
                <div class="quality__cards">
                <div class="quality__card">
                    <img src="<?php echo get_sub_field('food_image') ?>" alt="">
                    <h4><?php echo get_sub_field('food_title') ?></h4>
                    <p class="bg-primary p-3"><?php echo get_sub_field('food_par') ?></p>
                </div>

            </div>
            <?php endwhile; 
            else: 
                echo "No more slider";
        endif;
        ?>
            </div>

            </div>

      
    </section>
<?php get_footer();?>