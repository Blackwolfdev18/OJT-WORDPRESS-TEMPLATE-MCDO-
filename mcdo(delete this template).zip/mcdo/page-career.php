<?php get_header();?>
<section class="banner2 banner--food2"> <!--banner--food-->
    </section>
    <!-- YT-->
    <section class="quality">
        <div class="container">
            <div class="quality__header">
                <h3 class="mb-1">The McDonald's Experience</h3>
                <div class="yt-video">
                    <iframe width="100%" height="100%" src="https://www.youtube.com/embed/5EHhIX8UoKg" title="McDonald’s NXTGEN" frameborder="0" allow="accelerometer; autoplay; 
                    clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
                </div>
            </div>
        </div>
    </section>

    <!-- filter button -->
    <section class="cardyel">
        <div class="container">
            <div class="centerbtn">
            <button class="btn-red">Filter</button>
        </div>
            <div class="cardyel__wrapper">
            
            <?php $activity = new WP_Query(array(
                'post_type' => 'post',
                'category__in' => array( 2 ),
                'posts_per_page' => 2,
                'paged' =>  get_query_var('paged', 2) 
            
        )) ?>
            <?php if($activity->have_posts()) : while($activity->have_posts()) : $activity->the_post(); ?>

                <!-- card -->
                <div class="cardlong">
                    <div class="left">
                        <h3><?php the_title();?></h3>
                        <?php the_content() ?>
                    </div>
                    <div class="right">
                        <button class="btn-white">APPLY</button>
                    </div>
                </div>
                <?php endwhile;
                else:
                    echo "Nomore activity";
                endif;
            ?>

<div class="pagination">
        <?php 
        global $wp_query;
        $big = 999999999; // need an unlikely integer
        echo paginate_links( array(
            'base' => str_replace( $big, '%#%', esc_url( get_pagenum_link( $big ) ) ),
            'format' => '?paged=%#%',
            'current' => max( 1, get_query_var('paged') ),
            'total' => $activity->max_num_pages
        ) );
?>
            </div>
        </div>
    </section>
    <?php get_footer();?>